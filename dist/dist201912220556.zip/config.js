window.CONFIG = {
  baseURL: "http://192.168.123.10:9987/api",
  account: {
    username: 'admin',
    password: 'admin'
  }
};
